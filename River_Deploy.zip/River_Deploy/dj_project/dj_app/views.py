from django.shortcuts import render
from django.http import HttpResponse
import pickle
import numpy as np

my_dict={'element':None}

def index(request):

    if request.method == 'POST':

        temperature=request.POST['temperature']
        dissolvedoxy=request.POST['dissolvedoxy']
        ph=request.POST['ph']
        bio=request.POST['bio']
        faecal=request.POST['faecal']
        nitrate=request.POST['nitrate']
        coliform=request.POST['coliform']
        total_col=request.POST['total_col']
        conductivity=request.POST['conductivity']

        model=pickle.load(open('WQI_model.pkl','rb'))
        sc=pickle.load(open('scaler.pkl','rb'))

        arr=np.array([temperature,dissolvedoxy,ph,bio,faecal,nitrate,coliform,total_col,conductivity]).reshape(1,-1)
        arr=sc.transform(arr)

        # print(arr)
        pred=model.predict(arr)
        my_dict['element']=pred[0]
        # print(my_dict)

    return render(request,'index.html',context=my_dict)

# Create your views here.
